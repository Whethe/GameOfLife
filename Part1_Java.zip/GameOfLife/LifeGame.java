package GameOfLife;

/*
* Name: Jiajie Hao ID: 21012749
* Name: YUjia Gu   ID: 21012746

* We used the code from https://github.com/zpfbuaa/Game-Of-Life for reference��
* and we fully understood their implementation,
* added comments explaining the function of various parts of the code,
* and modified the window size to 20 * 20, cell color, and initial position of the window based on their code
* */


import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class LifeGame extends JFrame implements MouseMotionListener {
    private final World world;

    //JButton button = new JButton ("button");
    //static JMenu location=new JMenu();
    public LifeGame(int rows, int columns) {
        world = new World(rows, columns);
        world.setBackground(Color.LIGHT_GRAY);
        new Thread(world).start();
        add(world);
    }

    public static void main(String[] args) {

        //size of the board: 20*20
        LifeGame frame = new LifeGame(20, 20);

        frame.addMouseMotionListener(frame);
        JMenuBar menu = new JMenuBar();
        frame.setJMenuBar(menu);

        //toolbar
        JMenu options = new JMenu("Options");
        menu.add(options);
        JMenu changeSpeed = new JMenu("ChangeSpeed");
        menu.add(changeSpeed);
        JMenu other = new JMenu("Other");
        menu.add(other);

        //toolbar --- Options
        JMenuItem start = options.add("Start");
        start.addActionListener(frame.new StartActionListener());
        JMenuItem random = options.add("Random");
        random.addActionListener(frame.new RandomActionListener());
        JMenuItem stop = options.add("Stop");
        stop.addActionListener(frame.new StopActionListener());
        JMenuItem pause = options.add("Pause");
        pause.addActionListener(frame.new PauseActionListener());
        JMenuItem doItYourself = options.add("Add");
        doItYourself.addActionListener(frame.new DIYActionListener());
        JMenuItem clean = options.add("Kill");
        clean.addActionListener(frame.new CleanActionListener());

        //toolbar --- ChangeSpeed
        JMenuItem slow = changeSpeed.add("Slow");
        slow.addActionListener(frame.new SlowActionListener());
        JMenuItem fast = changeSpeed.add("Fast");
        fast.addActionListener(frame.new FastActionListener());
        JMenuItem hyper = changeSpeed.add("Hyper");
        hyper.addActionListener(frame.new HyperActionListener());

        //toolbar --- Other
        JMenuItem help = other.add("Help");
        help.addActionListener(frame.new HelpActionListener());
        JMenuItem about = other.add("About");
        about.addActionListener(frame.new AboutActionListener());

        //Gets the screen size and calculates the position of the window
        //so that the window can be displayed in the center of the screen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = 415;
        int height = 460;
        frame.setSize(width, height);
        int x = (screenSize.width - width) / 2;
        int y = (screenSize.height - height) / 2;
        frame.setLocation(x, y);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Game of Life");
        frame.setVisible(true);
        frame.setResizable(false);
    }

    //start the game
    class StartActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e) {
            //world.begintime=System.currentTimeMillis();
            world.setBackground(Color.LIGHT_GRAY);
            world.diy = false;
            world.clean = false;
            world.setShape();
        }
    }

    //random mode, can't diy or clean, generate random cells
    class RandomActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e) {
            world.diy = false;
            world.clean = false;
            world.setBackground(Color.LIGHT_GRAY);
            world.setRandom();
        }
    }

    //stop the game, clear cell, reset the background
    class StopActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e) {
            //world.time=0;
            world.setBackground(Color.LIGHT_GRAY);
            world.diy = false;
            world.clean = false;
            world.setStop();
        }
    }

    //pause the game
    class PauseActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            world.setBackground(Color.LIGHT_GRAY);
            world.diy = false;
            world.clean = false;
            world.setPause();
        }
    }

    //3 different modes of speed
    class SlowActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            world.changeSpeedSlow();
        }
    }

    class FastActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            world.changeSpeedFast();
        }
    }

    class HyperActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            world.changeSpeedHyper();
        }
    }

    //'Help' button
    class HelpActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, "Game of life project\n "
                    + "The Conway��s Game of Life is played on a grid, where cells have two states: survival or death, and a filled grid represents survival.\n"
                    + "There are only four rules of the game:\n "
                    + "1. When there is only one or no surviving cell around, the cell enters a dead state.\n"
                    + "2. When there are 2 or 3 living cells around, the cell remains intact.\n"
                    + "3. When there are four or more living cells around, the cell enters a dead state.\n"
                    + "4. When there are 3 viable cells around, the blank grid becomes viable cells.\n");
        }
    }

    //'About' button
    class AboutActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, "Name: Yujia GU       ID: 21012746\n"
                    + "Name: Jiajie Hao     ID: 21012749\n");
        }
    }

    //clear the frame
    class CleanActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e) {
            world.setPause();
            world.clean = true;
            world.diy = false;
            world.setBackground(Color.orange);
        }
    }

    //draw cells by player
    class DIYActionListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e) {
            world.setPause();
            world.diy = true;
            world.clean = false;
            world.setBackground(Color.gray);
        }
    }

    //draw the cells when dragging mouse
    @Override
    public void mouseDragged(MouseEvent e) {
        if (world.diy) {
            int x = e.getX();
            int y = e.getY();
            World.pauseshape[(y - 50) / 20][x / 20] = 1;
            world.setDiy();
        }
    }

    //clean the cells when moving mouse
    @Override
    public void mouseMoved(MouseEvent e) {
        if (world.clean) {
            int x = e.getX();
            int y = e.getY();
            World.pauseshape[(y - 50) / 20][x / 20] = 0;
            world.setDiy();
        }
    }
}

