#include <opencv2/opencv.hpp>
#include <ranges>

// 生命游戏是一种具有自动进化性质的细胞自动机模拟。可以使用 C++ 和 OpenCV 编写。
//
// 思路如下：
//
// 使用 OpenCV 创建一个矩阵来表示细胞网格，使用 0 表示死亡的细胞，1 表示存活的细胞。
//
// 循环遍历整个细胞网格，对于每一个细胞计算其周围 8 个细胞的存活状态。
//
// 根据游戏规则更新细胞状态。例如，如果一个细胞周围有 2 个或 3 个存活细胞，则该细胞将继续存活，否则它将死亡。
//
// 使用 OpenCV 的 GUI 功能在屏幕上显示细胞网格。
//
// 通过循环迭代步骤 2 - 4，来模拟游戏的进化过程。
//
// 使用 OpenCV 的交互功能，添加鼠标事件监听器，使用户可以手动设置细胞状态。
//
// 添加控制按钮，可以暂停 / 开始 / 清空游戏。
//
// 可以添加一些额外的功能，例如自动保存 / 加载游戏状态，更改游戏规则，添加颜色等。
// 使用 OpenCV 创建一个矩阵来表示细胞网格，使用 0 表示死亡的细胞，1 表示存活的细胞。
constexpr int COLS = 150; // 列
constexpr int ROWS = 80; // 行
constexpr int CELLSIZE = 10; // cell size
[[maybe_unused]] constexpr int CELLCOUNT = COLS * ROWS; // 细胞总数
 
using CellArray2 = std::array<std::array<bool, COLS>, ROWS>;
 
 
class CellGrid
{
public:
    static CellArray2 NextCellGrid;
    static CellArray2 CurCellGrid;
    cv::Mat grid;
     
    CellGrid(): grid(cv::Mat(CELLSIZE * ROWS, CELLSIZE * COLS, CV_8UC3, cv::Scalar(255, 255, 255)))
    {
    }
     
    void DrawCellGrid()
    {
        for (int i = 0; i < ROWS; i++)
        {
            for (int j = 0; j < COLS; j++)
            {
                cv::Mat cell = GenerateCell(CurCellGrid[i][j]);
                cell.copyTo(grid(cv::Rect(j * CELLSIZE, i * CELLSIZE, CELLSIZE, CELLSIZE)));
            }
        }
        cv::imshow("Game of Life", grid);
        //注册鼠标点击 其实不应该写在这里的 。。。不改了
        cv::setMouseCallback("Game of Life", onMouse, &grid);
    }
     
    void Start()
    {
        while (true)
        {
            int key = cv::waitKey(100);
            switch (key)
            {
                case 'r':
                    RandomCell();
                    DrawCellGrid();
                    break;
                    //enter
                case 13:
                    UpdateCell();
                    DrawCellGrid();
                    break;
                    //esc
                case 27:
                    exit(0);
                    break;
                     
                case 'z':
                    //每隔0.5s刷新一次
                    while (true)
                    {
                        UpdateCell();
                        DrawCellGrid();
                        int key = cv::waitKey(200);
                        if (key == 27)
                        {
                            break;
                        }
                    }
                    break;
                case 'c':
                    ClearCellGrid();
                    DrawCellGrid();
                    break;default:;
            }
        }
    }
     
private:
    //清屏
    static void ClearCellGrid()
    {
        CurCellGrid = {false};
    }
     
     
    //随机生成细胞
    static void RandomCell()
    {
        for (int i = 0; i < ROWS; i++)
        {
            for (int j = 0; j < COLS; j++)
            {
                CurCellGrid[i][j] = std::rand() % 2;
            }
        }
    }
     
    //更新细胞状态
    static void UpdateCell()
    {
        for (int i = 0; i < ROWS; i++)
        {
            for (int j = 0; j < COLS; j++)
            {
                int count = 0;
                for (int m = -1; m <= 1; m++)
                {
                    for (int n = -1; n <= 1; n++)
                    {
                        if (m == 0 && n == 0)
                        {
                            continue;
                        }
                        int row = (i + m + ROWS) % ROWS;
                        int col = (j + n + COLS) % COLS;
                        if (CurCellGrid[row][col])
                        {
                            count++;
                        }
                    }
                }
                if (CurCellGrid[i][j])
                {
                    if (count == 2 || count == 3)
                    {
                        NextCellGrid[i][j] = true;
                    }
                    else
                    {
                        NextCellGrid[i][j] = false;
                    }
                }
                else
                {
                    if (count == 3)
                    {
                        NextCellGrid[i][j] = true;
                    }
                    else
                    {
                        NextCellGrid[i][j] = false;
                    }
                }
            }
        }
        CurCellGrid = NextCellGrid;
    }
     
     
    //鼠标点击事件
    static void onMouse(int event, int x, int y, int flags, void* param)
    {
        if (event == cv::EVENT_LBUTTONDOWN)
        {
            cv::Mat grid = *(cv::Mat*)param;
            int row = y / CELLSIZE;
            int col = x / CELLSIZE;
            if (CurCellGrid[row][col])
            {
                CurCellGrid[row][col] = false;
                cv::Mat cell = GenerateCell(false);
                cell.copyTo(grid(cv::Rect(col * CELLSIZE, row * CELLSIZE, CELLSIZE, CELLSIZE)));
            }
            else
            {
                CurCellGrid[row][col] = true;
                cv::Mat cell = GenerateCell(true);
                cell.copyTo(grid(cv::Rect(col * CELLSIZE, row * CELLSIZE, CELLSIZE, CELLSIZE)));
            }
             
            cv::imshow("Game of Life", grid);
        }
    }
     
     
    static cv::Mat GenerateCell(bool isAlive)
    {
        cv::Mat cell(CELLSIZE, CELLSIZE, CV_8UC3, cv::Scalar(255, 255, 255));
        cv::rectangle(cell, cv::Point(0, 0), cv::Point(CELLSIZE - 1, CELLSIZE - 1), cv::Scalar(0, 0, 0), 1);
        if (isAlive)
        {
            cell.setTo(cv::Scalar(0, 0, 0));
        }
        return cell;
    }
};

CellArray2 CellGrid::CurCellGrid;
CellArray2 CellGrid::NextCellGrid;


int main(int argc, char* argv[])
{
    CellGrid cellGrid;
    cellGrid.DrawCellGrid();
    cellGrid.Start();
}
